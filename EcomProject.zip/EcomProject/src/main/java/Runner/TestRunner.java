package Runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)

@io.cucumber.junit.CucumberOptions(
		features= "C:/Users/sasin/eclipse-workspace/EcomProject/src/main/java/Feature"
		,glue= {"StepDefinations"}
	
		)
public class TestRunner {

	
}
