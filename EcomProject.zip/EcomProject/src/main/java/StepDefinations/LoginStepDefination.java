package StepDefinations;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefination {

	
	WebDriver driver;
	
	@Given("^user is already on loginIn Page$")
	
	public void user_is_already_on_logIn_page() {
		
		System.setProperty("webdriver.chrome.driver","C:/Users/sasin/eclipse-workspace/EcomProject/src/main/java/Executable/chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
				
	}
	
	@When("^title of login page is Amazon$")
	public void title_of_login_page_is_Amazon() {
		System.out.println(driver.getCurrentUrl());
									
	}
	@Then("^user enters username and password$")
	public void user_enters_username_and_password() throws InterruptedException {
	
	Thread.sleep(10000);
	Actions a =new Actions(driver);
	WebElement move = driver.findElement(By.cssSelector("a[id='nav-link-accountList']"));
	a.moveToElement(move).click().build().perform();
	
	driver.findElement(By.id("ap_email")).sendKeys("9920737896");
	driver.findElement(By.id("continue")).click();
	driver.findElement(By.id("ap_password")).sendKeys("abcd@123");
		
	
	}
	
	@Then("^user click on Signin Button$")
	public void user_click_on_signin_button() {
		driver.findElement(By.id("signInSubmit")).click();
	   
	}	
	
	@Then("^user is on home page$")
	public void user_is_on_home_page() throws InterruptedException {
	   String title = driver.getTitle();
	   System.out.println("Home Page::"+title);
	   
	}
	 @Then("^user enter the pillow in search box$")
	 
	 public void user_enter_the_pillow_in_search_box() {
	   Actions a =new Actions(driver);
	   a.moveToElement(driver.findElement(By.id("twotabsearchtextbox"))).click().keyDown(Keys.SHIFT).sendKeys("Duroflex Neck Pro Orthopedic Medium Soft Support Pillow - 69 x 43 cm").build().perform();
	   driver.findElement(By.className("nav-input")).click();	 
	   driver.get("https://www.amazon.in/s?k=DUROFLEX+NECK+PRO+ORTHOPEDIC+MEDIUM+SOFT+SUPPORT+PILLOW+_+%5E%28+X+%24%23+CM&ref=nb_sb_noss");
	
	 
	driver.findElement(By.partialLinkText("Duroflex Neck Pro Orthopedic Medium Soft Support Pillow")).click();
	 }
	 @Then("^user select the pillow to buy$")
	 public void user_select_the_pillow_to_buy() throws InterruptedException {
	 
	Set<String>ids= driver.getWindowHandles();
	Iterator<String> it = ids.iterator();
	String parentid= it.next();
	String childid = it.next();
	driver.switchTo().window(childid);
	driver.findElement(By.id("buy-now-button")).click();
	 }
     @Then("^user select the address to deliver$")
     
     public void user_select_the_address_to_deliver() throws InterruptedException {
	driver.get("https://www.amazon.in/gp/buy/addressselect/handlers/display.html?hasWorkingJavascript=1");
	Thread.sleep(5000);
    driver.findElement(By.xpath("//body/div[contains(@class,'checkout checkout-as checkout-as-desktop')]/div[contains(@class,'a-container')]/div[contains(@class,'clearfix')]/form[1]/div[1]/div[1]/div[2]/span[1]/a[1]")).click();
	//driver.findElement(By.xpath("//input[@className='a-button-text'])")).click();
     }	 
     
     @Then("^user perform the transaction$")
     
    public void user_perform_the_transaction() {
    driver.get("https://www.amazon.in/gp/buy/payselect/handlers/display.html?hasWorkingJavascript=1");    	 
    driver.findElement(By.id("pp-nqe7i7-117")).click();
    driver.findElement(By.id("pp-nqe7i7-124")).sendKeys("123");
    driver.findElement(By.xpath("//span[@id='pp-nqe7i7-284']//input[@name='ppw-widgetEvent:SetPaymentPlanSelectContinueEvent']")).click();
    driver.findElement(By.xpath("//input[@name='placeYourOrder1']")).click();
    System.out.println("Order Successfull");
      
      	
	 }
	
	}

	

